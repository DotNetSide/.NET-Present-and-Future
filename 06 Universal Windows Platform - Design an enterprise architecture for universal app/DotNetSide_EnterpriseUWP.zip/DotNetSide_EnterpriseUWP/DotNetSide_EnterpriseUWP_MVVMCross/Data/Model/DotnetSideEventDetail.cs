﻿using SQLite.Net.Attributes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_MVVMCross.Data.Model
{
    public class DotnetSideEventDetail
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string PubblishData { get; set; }
        public string LinkAgenda { get; set; }

        public ObservableCollection<string> Lines
        {
            get
            {
                string body = Description;
                ObservableCollection<string> observables = new ObservableCollection<string>();
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < body.Length; i++)
                {
                    builder.Append(body[i]);
                    if (((body[i] == '.') && ((i + 1) != body.Length)) && (body[(int)(i + 1)] == ' '))
                    {
                        observables.Add(builder.ToString());
                        builder = new StringBuilder();
                        i++;
                    }
                }
                observables.Add(builder.ToString());
                return observables;
            }
        }
    }
}
