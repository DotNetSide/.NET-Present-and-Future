﻿using MvvmCross.Plugins.Messenger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_MVVMCross.Infrastructure.Event
{
    public class SetFavoriteEventArgs: MvxMessage
    {
        public SetFavoriteEventArgs(object sender, string id, bool isFavorite, Guid instanceId)
            :base(sender)
        {
            Id = id;
            IsFavorite = isFavorite;
            InstanceID = instanceId;
        }
        public Guid InstanceID { get; set; }
        public string Id { get; set; }
        public bool IsFavorite { get; set; }
    }
}
