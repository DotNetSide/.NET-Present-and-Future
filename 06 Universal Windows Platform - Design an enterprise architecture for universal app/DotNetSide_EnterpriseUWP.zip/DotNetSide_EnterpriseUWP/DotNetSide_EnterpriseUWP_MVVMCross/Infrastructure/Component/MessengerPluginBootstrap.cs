

using MvvmCross.Platform.Plugins;

namespace DotNetSide_EnterpriseUWP_MVVMCross.Infrastructure.Component
{
    public class MessengerPluginBootstrap
        : MvxPluginBootstrapAction<MvvmCross.Plugins.Messenger.PluginLoader>
    {
    }
}