﻿using MvvmCross.Core.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MvvmCross.Platform.IoC;
using DotNetSide_EnterpriseUWP_MVVMCross.ViewModels;
using MvvmCross.Platform;
using DotNetSide_EnterpriseUWP_MVVMCross.Interface;
using DotNetSide_EnterpriseUWP_MVVMCross.Service;
using DotNetSide_EnterpriseUWP_MVVMCross.Data;

namespace DotNetSide_EnterpriseUWP_MVVMCross.Infrastructure.Component
{
    public class CrossApp : MvxApplication
    {
        public override void Initialize()
        {
            CreatableTypes()
                .EndingWith("Service")
                .AsInterfaces()
                .RegisterAsLazySingleton();

            
            Mvx.LazyConstructAndRegisterSingleton<IDataService, DataService>();
            Mvx.LazyConstructAndRegisterSingleton<IAppService, AppService>();
            Mvx.LazyConstructAndRegisterSingleton<IHttpService, HttpService>();

            RegisterAppStart<MainViewModel>();
        }
    }
}
