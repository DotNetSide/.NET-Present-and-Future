﻿using DotNetSide_EnterpriseUWP_MVVMCross.Data.Model;
using DotNetSide_EnterpriseUWP_MVVMCross.Infrastructure.Event;
using DotNetSide_EnterpriseUWP_MVVMCross.Interface;
using MvvmCross.Core.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_MVVMCross.ViewModels
{
    public class DetailViewModel : MvxViewModel
    {

        public DetailViewModel(IAppService appService)
        {
            AppService = appService;
        }

        public IAppService AppService { get; set; }

        private DotnetSideEvent _event;

        private MvxCommand<object> _loadedCommand;
        public MvxCommand<object> LoadedCommand
        {
            get
            {
                return _loadedCommand ?? (_loadedCommand = new MvxCommand<object>(
                    async x =>
                    {
                        try
                        {
                            SubTitle = "MVVMCross edition";

                            if (_event != null)
                            {
                                EventDetail = await AppService.Http.GetEventDetail(_event.Id, _event.LinkDetail);
                            }
                        }
                        catch (Exception ex)
                        {
                            new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
                        }
                    }));
            }
        }

        private MvxCommand<object> _goBack;
        public MvxCommand<object> GoBack
        {
            get
            {
                return _goBack ?? (_goBack = new MvxCommand<object>(
                     x =>
                    {
                        Close(this);
                    }));
            }
        }

        private MvxCommand<string> _manageFavorite;
        public MvxCommand<string> ManageFavorite
        {
            get
            {
                return _manageFavorite ?? (_manageFavorite = new MvxCommand<string>(
                    x =>
                    {
                        try
                        {
                            if (EventDetail != null)
                            {
                                AppService.Messenger.Publish(new SetFavoriteEventArgs(this, EventDetail.Id, Convert.ToBoolean(x), Guid.NewGuid()));
                            }
                        }
                        catch (Exception ex)
                        {
                            new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
                        }
                    }));
            }
        }

        private MvxCommand<object> _openAgenda;
        public MvxCommand<object> OpenAgenda
        {
            get
            {
                return _openAgenda ?? (_openAgenda = new MvxCommand<object>(
                     x =>
                     {
                         if (EventDetail != null && !String.IsNullOrEmpty(EventDetail.LinkAgenda))
                         {
                             Windows.System.Launcher.LaunchUriAsync(new Uri(EventDetail.LinkAgenda));
                         }

                     }));
            }
        }

        private string _title;
        public string Title
        {

            get
            {
                return _title;
            }
            set
            {
                if (value != _title)
                {
                    _title = value;
                    RaisePropertyChanged("Title");
                }
            }
        }

        private string _subtitle;
        public string SubTitle
        {

            get
            {
                return _subtitle;
            }
            set
            {
                if (value != _subtitle)
                {
                    _subtitle = value;
                    RaisePropertyChanged("SubTitle");
                }
            }
        }

        private DotnetSideEventDetail _eventDetail;
        public DotnetSideEventDetail EventDetail
        {
            get
            {
                return _eventDetail;
            }
            set
            {
                _eventDetail = value;
                RaisePropertyChanged("EventDetail");

            }
        }

        public void Init(DotnetSideEvent parameter)
        {
            if (parameter != null)
            {
                _event = parameter;
                Title = _event.Title;
            }
        }
    }
}
