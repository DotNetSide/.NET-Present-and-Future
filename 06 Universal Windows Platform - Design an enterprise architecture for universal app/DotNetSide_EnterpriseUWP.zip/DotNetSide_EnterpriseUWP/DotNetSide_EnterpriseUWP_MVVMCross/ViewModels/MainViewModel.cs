﻿using DotNetSide_EnterpriseUWP_MVVMCross.Data.Model;
using DotNetSide_EnterpriseUWP_MVVMCross.Infrastructure.Event;
using DotNetSide_EnterpriseUWP_MVVMCross.Interface;
using MvvmCross.Core.ViewModels;
using MvvmCross.Plugins.Messenger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace DotNetSide_EnterpriseUWP_MVVMCross.ViewModels
{
    public class MainViewModel : MvxViewModel
    {
        private readonly MvxSubscriptionToken _token;

        public MainViewModel(IAppService appService)
        {
            AppService = appService;
            _token = AppService.Messenger.SubscribeOnMainThread<SetFavoriteEventArgs>(SetFavorite);
        }

        public IAppService AppService { get; set; }


        private MvxCommand<object> _loadedCommand;
        public MvxCommand<object> LoadedCommand
        {
            get
            {
                return _loadedCommand ?? (_loadedCommand = new MvxCommand<object>(
                    async x =>
                    {
                        try
                        {
                            Title = "DotNetSide Journal";

                            SubTitle = "MVVMCross edition";

                            AppService.Data.CreateDatabase();

                            await LoadEvents();
                        }
                        catch (Exception ex)
                        {
                            new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
                        }
                    }));
            }
        }

        private MvxCommand<ItemClickEventArgs> _selectItemCommand;
        public MvxCommand<ItemClickEventArgs> SelectItem
        {
            get
            {
                return _selectItemCommand ?? (_selectItemCommand = new MvxCommand<ItemClickEventArgs>(
                    x =>
                    {
                        try
                        {
                            ShowViewModel<DetailViewModel>(x.ClickedItem);
                        }
                        catch (Exception ex)
                        {
                            new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
                        }
                    }));
            }
        }


        private List<DotnetSideEvent> _events;
        public List<DotnetSideEvent> Events
        {
            get
            {
                return _events;
            }
            set
            {
                _events = value;
                RaisePropertyChanged("Events");

            }
        }

        private string _title;
        public string Title
        {

            get
            {
                return _title;
            }
            set
            {
                if (value != _title)
                {
                    _title = value;
                    RaisePropertyChanged("Title");
                }
            }
        }

        private string _subtitle;
        public string SubTitle
        {

            get
            {
                return _subtitle;
            }
            set
            {
                if (value != _subtitle)
                {
                    _subtitle = value;
                    RaisePropertyChanged("SubTitle");
                }
            }
        }

        private async Task LoadEvents()
        {
            var evs = AppService.Data.GetEvents();

            if (evs == null || evs.Count == 0)
            {
                evs = await AppService.Http.GetEvents();
                AppService.Data.AddEvents(evs);
            }

            Events = evs;
        }

        private void SetFavorite(SetFavoriteEventArgs e)
        {
            if (e != null)
            {
                AppService.Data.SetIsFavorite(e.Id, e.IsFavorite);

                var el = Events.FirstOrDefault(x => x.Id == e.Id);

                if (el != null)
                {
                    el.IsFavorite = e.IsFavorite;
                }
            }
        }
    }
}
