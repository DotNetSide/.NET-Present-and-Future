﻿using DotNetSide_EnterpriseUWP_MVVMCross.Interface;
using MvvmCross.Plugins.Messenger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_MVVMCross.Service
{
    public class AppService : IAppService
    {
        public AppService(IHttpService httpService, IDataService dataService, IMvxMessenger messenger)
        {
            Http = httpService;
            Data = dataService;
            Messenger = messenger;
        }

        public IHttpService Http { get; private set; }

        public IDataService Data { get; private set; }

        public IMvxMessenger Messenger { get; private set; }
    }
}
