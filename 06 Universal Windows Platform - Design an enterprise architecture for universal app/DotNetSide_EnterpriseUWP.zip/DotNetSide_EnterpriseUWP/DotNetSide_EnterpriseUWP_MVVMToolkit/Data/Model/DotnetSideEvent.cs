﻿using GalaSoft.MvvmLight;
using SQLite.Net.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_MVVMToolkit.Data.Model
{
    [Table("DotnetSideEvent")]
    public class DotnetSideEvent : INotifyPropertyChanged
    {
        [PrimaryKey]
        public string Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime PubblishData { get; set; }
		public string LinkDetail { get; set; }

        private bool _isFavorite;
        public bool IsFavorite
        {

            get
            {
                return _isFavorite;
            }
            set
            {
                if (value != _isFavorite)
                {
                    _isFavorite = value;
                    OnPropertyChanged("IsFavorite");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
