﻿using DotNetSide_EnterpriseUWP_MVVMToolkit.Data.Model;
using DotNetSide_EnterpriseUWP_MVVMToolkit.Interface;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_MVVMToolkit.Service
{
    public class HttpService : IHttpService
    {
        public async Task<List<DotnetSideEvent>> GetEvents()
        {
            string main_url = "http://dotnetside.org/eventi/default.aspx";
            string event_url = "http://dotnetside.org/eventi/{0}";

            List<DotnetSideEvent> result = new List<DotnetSideEvent>();
            string response = await HttpGet(main_url);

            if (!String.IsNullOrEmpty(response))
            {
                var doc = new HtmlDocument();
                doc.LoadHtml(response);

                var trk = from dc in doc.DocumentNode.Descendants("table").Where(x =>
                                                           x.Attributes.Any(y => y.Name == "id") &&
                                                            x.Attributes["id"].Value == "GridViewEventi").FirstOrDefault()
                                                          .Descendants("tr")
                                                          .Select(n => n.Elements("td").ToList())
                          where dc.Count == 2
                          select new DotnetSideEvent()
                          {
                              PubblishData = DateTime.Parse(dc.FirstOrDefault().InnerText),
                              Title = ClearHtml(dc.LastOrDefault().InnerText),
                              LinkDetail = String.Format(event_url, dc.LastOrDefault().ChildNodes.First(x => x.Name.ToUpperInvariant() == "A").Attributes.First(x => x.Name.ToUpperInvariant() == "HREF").Value),
                              Id = dc.LastOrDefault().ChildNodes.First(x => x.Name.ToUpperInvariant() == "A").Attributes.First(x => x.Name.ToUpperInvariant() == "HREF").Value
                          };

                result = trk.ToList();
            }

            return result;
        }

        public async Task<DotnetSideEventDetail> GetEventDetail(string id, string url)
        {
            DotnetSideEventDetail result = null;

            if (!String.IsNullOrEmpty(url))
            {
                string response = await HttpGet(url);

                if (!String.IsNullOrEmpty(response))
                {
                    var doc = new HtmlDocument();
                    doc.LoadHtml(response);

                    var trk = (from dc in doc.DocumentNode.Descendants("table").Where(x =>
                                            x.Attributes.Any(y => y.Name == "align") &&
                                            x.Attributes["align"].Value == "center").FirstOrDefault()
                                                         .Descendants("tr")
                                                         .Select(n => n.Elements("td").ToList())

                               select dc.Select(x => ClearText(x.InnerText))).SelectMany(x => x).Where(x => !String.IsNullOrEmpty(x)).ToList();

                    result = new DotnetSideEventDetail() { PubblishData = trk[4], Title = ClearHtml(trk[3]), Description = ClearHtml(trk[5]), Id = id };

                    result.LinkAgenda = doc.DocumentNode.Descendants("a").Select(x => x.Attributes["href"].Value).Where(x => x.Contains("dotnetside.org/content")).FirstOrDefault();
                }
            }

            return result;
        }


        private string ClearText(string source)
        {
            var newString = string.Join(" ", Regex.Split(source, @"(?:\r\n|\n|\r|\t|  )"));
            return newString.Trim();
        }

        public string ClearHtml(string source)
        {
            string str = ClearText(source);

            str = WebUtility.HtmlDecode(str);

            return Regex.Replace(str, "<.*?>", string.Empty);
        }

        public async Task<string> HttpGet(string url)
        {
            string content = "";

            if (!String.IsNullOrEmpty(url))
            {
                using (var httpClient = new HttpClient())
                {
                    var response = await httpClient.GetAsync(new Uri(url));
                    content = await response.Content.ReadAsStringAsync();
                }
            }

            return content;
        }
    }
}
