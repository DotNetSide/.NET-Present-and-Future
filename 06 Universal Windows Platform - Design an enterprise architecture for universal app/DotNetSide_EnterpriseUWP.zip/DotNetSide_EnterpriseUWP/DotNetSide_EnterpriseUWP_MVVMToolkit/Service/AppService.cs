﻿using DotNetSide_EnterpriseUWP_MVVMToolkit.Interface;
using GalaSoft.MvvmLight.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_MVVMToolkit.Service
{
    public class AppService : IAppService
    {
        public AppService(IHttpService httpService, IDataService dataService, INavigationService navigationService)
        {
            Http = httpService;
            Data = dataService;
            Navigation = navigationService;
        }

        public IHttpService Http { get; private set; }

        public IDataService Data { get; private set; }

        public INavigationService Navigation { get; private set; }

    }
}
