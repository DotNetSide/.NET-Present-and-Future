﻿using System.Collections.Generic;
using DotNetSide_EnterpriseUWP_MVVMToolkit.Data.Model;

namespace DotNetSide_EnterpriseUWP_MVVMToolkit.Interface
{
    public interface IDataService
    {
        string DatabasePath { get; set; }

        void CreateDatabase();
        bool ExistTable<T>() where T : class;
        List<DotnetSideEvent> GetEvents();
        void AddEvents(List<DotnetSideEvent> events);
        void SetIsFavorite(string id, bool isFavorite);
    }
}