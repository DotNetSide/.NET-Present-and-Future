﻿using GalaSoft.MvvmLight.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_MVVMToolkit.Interface
{
    public interface IAppService
    {
        IHttpService Http { get; }

        IDataService Data { get; }

        INavigationService Navigation { get; }
    }
}
