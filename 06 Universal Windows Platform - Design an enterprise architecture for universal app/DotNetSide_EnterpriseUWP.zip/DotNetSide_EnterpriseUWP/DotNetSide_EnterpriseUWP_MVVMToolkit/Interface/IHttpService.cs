﻿using DotNetSide_EnterpriseUWP_MVVMToolkit.Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_MVVMToolkit.Interface
{
    public interface IHttpService
    {
        Task<List<DotnetSideEvent>> GetEvents();

        Task<DotnetSideEventDetail> GetEventDetail(string id, string url);
    }
}
