﻿using DotNetSide_EnterpriseUWP_MVVMToolkit.Data.Model;
using DotNetSide_EnterpriseUWP_MVVMToolkit.Infrastructure.Event;
using DotNetSide_EnterpriseUWP_MVVMToolkit.Interface;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_MVVMToolkit.ViewModels
{
    public class DetailPageViewModel : ViewModelBase, INavigable
    {

        public DetailPageViewModel(IAppService appService)
        {
            AppService = appService;
        }

        public IAppService AppService { get; set; }

        private DotnetSideEvent _event;

        private RelayCommand<object> _loadedCommand;
        public RelayCommand<object> LoadedCommand
        {
            get
            {
                return _loadedCommand ?? (_loadedCommand = new RelayCommand<object>(
                    async x =>
                    {
                        try
                        {
                            SubTitle = "MVVM Light Toolkit edition";

                            if (_event != null)
                            {
                                EventDetail = await AppService.Http.GetEventDetail(_event.Id, _event.LinkDetail);
                            }
                        }
                        catch (Exception ex)
                        {
                            new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
                        }
                    }));
            }
        }

        private RelayCommand<object> _goBack;
        public RelayCommand<object> GoBack
        {
            get
            {
                return _goBack ?? (_goBack = new RelayCommand<object>(
                     x =>
                    {
                        AppService.Navigation.GoBack();
                    }));
            }
        }

        private RelayCommand<string> _manageFavorite;
        public RelayCommand<string> ManageFavorite
        {
            get
            {
                return _manageFavorite ?? (_manageFavorite = new RelayCommand<string>(
                    x =>
                    {
                        try
                        {
                            if (EventDetail != null)
                            {
                                Messenger.Default.Send(new SetFavoriteEventArgs() { Id = EventDetail.Id, IsFavorite = Convert.ToBoolean(x) });
                            }
                        }
                        catch (Exception ex)
                        {
                            new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
                        }
                    }));
            }
        }

        private RelayCommand<object> _openAgenda;
        public RelayCommand<object> OpenAgenda
        {
            get
            {
                return _openAgenda ?? (_openAgenda = new RelayCommand<object>(
                     x =>
                     {
                         if (EventDetail != null && !String.IsNullOrEmpty(EventDetail.LinkAgenda))
                         {
                             Windows.System.Launcher.LaunchUriAsync(new Uri(EventDetail.LinkAgenda));
                         }

                     }));
            }
        }

        private string _title;
        public string Title
        {

            get
            {
                return _title;
            }
            set
            {
                if (value != _title)
                {
                    _title = value;
                    RaisePropertyChanged("Title");
                }
            }
        }

        private string _subtitle;
        public string SubTitle
        {

            get
            {
                return _subtitle;
            }
            set
            {
                if (value != _subtitle)
                {
                    _subtitle = value;
                    RaisePropertyChanged("SubTitle");
                }
            }
        }

        private DotnetSideEventDetail _eventDetail;
        public DotnetSideEventDetail EventDetail
        {
            get
            {
                return _eventDetail;
            }
            set
            {
                _eventDetail = value;
                RaisePropertyChanged("EventDetail");

            }
        }

        public void Activate(object parameter)
        {
            if (parameter != null)
            {
                _event = parameter as DotnetSideEvent;
                Title = _event.Title;
            }
        }
    }
}
