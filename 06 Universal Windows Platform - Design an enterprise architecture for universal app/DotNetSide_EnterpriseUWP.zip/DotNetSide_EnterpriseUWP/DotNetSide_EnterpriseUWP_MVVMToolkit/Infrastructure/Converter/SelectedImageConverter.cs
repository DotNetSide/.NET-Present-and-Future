﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Data;

namespace DotNetSide_EnterpriseUWP_MVVMToolkit.Infrastructure.Converter
{
    public class SelectedImageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language)
        {
            if (value == null)
                return "ms-appx:///Assets/star_grey.png";

            bool bVal = System.Convert.ToBoolean(value);

            if(bVal)
                return "ms-appx:///Assets/star_yel.png";
            else
                return "ms-appx:///Assets/star_grey.png";
        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }
}
