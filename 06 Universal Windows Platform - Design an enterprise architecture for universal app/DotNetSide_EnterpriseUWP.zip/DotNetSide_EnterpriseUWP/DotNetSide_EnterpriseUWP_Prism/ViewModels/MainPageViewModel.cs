﻿using DotNetSide_EnterpriseUWP_Prism.Data.Model;
using DotNetSide_EnterpriseUWP_Prism.Infrastructure.Event;
using DotNetSide_EnterpriseUWP_Prism.Interface;
using Prism.Commands;
using Prism.Windows.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace DotNetSide_EnterpriseUWP_Prism.ViewModels
{
    public class MainPageViewModel : ViewModelBase, IMainPageViewModel
    {

        public MainPageViewModel(IAppService appService)
        {
            AppService = appService;
            AppService.Event.GetEvent<SetFavoriteEvent>().Subscribe(SetFavorite);
        }

        public IAppService AppService { get; set; }

        private DelegateCommand<object> _loadedCommand;
        public DelegateCommand<object> LoadedCommand
        {
            get
            {
                return _loadedCommand ?? (_loadedCommand = new DelegateCommand<object>(
                    async x =>
                    {
                        try
                        {
                            Title = "DotNetSide Journal";

                            SubTitle = "Prism edition";

                            AppService.Data.CreateDatabase();

                            await LoadEvents();
                        }
                        catch (Exception ex)
                        {
                            new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
                        }
                    }));
            }
        }

        private DelegateCommand<ItemClickEventArgs> _selectItemCommand;
        public DelegateCommand<ItemClickEventArgs> SelectItem
        {
            get
            {
                return _selectItemCommand ?? (_selectItemCommand = new DelegateCommand<ItemClickEventArgs>(
                    x =>
                    {
                        try
                        {
                            AppService.Navigation.Navigate("Detail", x.ClickedItem);
                        }
                        catch (Exception ex)
                        {
                            new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
                        }
                    }));
            }
        }
        

        private List<DotnetSideEvent> _events;
        public List<DotnetSideEvent> Events
        {
            get
            {
                return _events;
            }
            set
            {
                _events = value;
                OnPropertyChanged("Events");

            }
        }

        private string _title;
        public string Title
        {

            get
            {
                return _title;
            }
            set
            {
                if (value != _title)
                {
                    _title = value;
                    OnPropertyChanged("Title");
                }
            }
        }

        private string _subtitle;
        public string SubTitle
        {

            get
            {
                return _subtitle;
            }
            set
            {
                if (value != _subtitle)
                {
                    _subtitle = value;
                    OnPropertyChanged("SubTitle");
                }
            }
        }

        private async Task LoadEvents()
        {
            var evs = AppService.Data.GetEvents();

            if(evs == null || evs.Count == 0)
            {
                evs = await AppService.Http.GetEvents();
                AppService.Data.AddEvents(evs);
            }

            Events = evs;
        }

        private void SetFavorite(SetFavoriteEventArgs e)
        {
            if(e != null)
            {
                AppService.Data.SetIsFavorite(e.Id, e.IsFavorite);

                var el = Events.FirstOrDefault(x => x.Id == e.Id);

                if(el != null)
                {
                    el.IsFavorite = e.IsFavorite;
                }
            }
        }
    }
}
