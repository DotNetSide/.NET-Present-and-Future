﻿using DotNetSide_EnterpriseUWP_Prism.Data.Model;
using DotNetSide_EnterpriseUWP_Prism.Infrastructure.Event;
using DotNetSide_EnterpriseUWP_Prism.Interface;
using System;
using Prism.Windows.Mvvm;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prism.Commands;
using Windows.UI.Xaml.Navigation;
using Prism.Windows.Navigation;

namespace DotNetSide_EnterpriseUWP_Prism.ViewModels
{
    public class DetailPageViewModel : ViewModelBase, IDetailPageViewModel
    {
        public DetailPageViewModel(IAppService appService)
        {
            AppService = appService;
        }
        
        public IAppService AppService { get; set; }

        private DotnetSideEvent _event;

        public override void OnNavigatedTo(NavigatedToEventArgs e, Dictionary<string, object> viewModelState)
        {
            if (e.Parameter != null)
            {
                _event = e.Parameter as DotnetSideEvent;
                Title = _event.Title;
            }

            base.OnNavigatedTo(e, viewModelState);
        }
        
        private DelegateCommand<object> _loadedCommand;
        public DelegateCommand<object> LoadedCommand
        {
            get
            {
                return _loadedCommand ?? (_loadedCommand = new DelegateCommand<object>(
                    async x =>
                    {
                        try
                        {
                            SubTitle = "Prism edition";

                            if (_event != null)
                            {
                                EventDetail = await AppService.Http.GetEventDetail(_event.Id, _event.LinkDetail);
                            }
                        }
                        catch (Exception ex)
                        {
                            new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
                        }
                    }));
            }
        }

        private DelegateCommand<object> _goBack;
        public DelegateCommand<object> GoBack
        {
            get
            {
                return _goBack ?? (_goBack = new DelegateCommand<object>(
                     x =>
                    {
                        if(AppService.Navigation.CanGoBack())
                        {
                            AppService.Navigation.GoBack();
                        }
                    }));
            }
        }

        private DelegateCommand<string> _manageFavorite;
        public DelegateCommand<string> ManageFavorite
        {
            get
            {
                return _manageFavorite ?? (_manageFavorite = new DelegateCommand<string>(
                    x =>
                    {
                        try
                        {
                            if (EventDetail != null)
                            {
                                AppService.Event.GetEvent<SetFavoriteEvent>().Publish(new SetFavoriteEventArgs() { Id = EventDetail.Id, IsFavorite = Convert.ToBoolean(x) });
                            }
                        }
                        catch (Exception ex)
                        {
                            new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
                        }
                    }));
            }
        }

        private DelegateCommand<object> _openAgenda;
        public DelegateCommand<object> OpenAgenda
        {
            get
            {
                return _openAgenda ?? (_openAgenda = new DelegateCommand<object>(
                     x =>
                     {
                         if (EventDetail != null && !String.IsNullOrEmpty(EventDetail.LinkAgenda))
                         {
                             Windows.System.Launcher.LaunchUriAsync(new Uri(EventDetail.LinkAgenda));
                         }

                     }));
            }
        }

        private string _title;
        public string Title
        {

            get
            {
                return _title;
            }
            set
            {
                if (value != _title)
                {
                    _title = value;
                    OnPropertyChanged("Title");
                }
            }
        }

        private string _subtitle;
        public string SubTitle
        {

            get
            {
                return _subtitle;
            }
            set
            {
                if (value != _subtitle)
                {
                    _subtitle = value;
                    OnPropertyChanged("SubTitle");
                }
            }
        }

        private DotnetSideEventDetail _eventDetail;
        public DotnetSideEventDetail EventDetail
        {
            get
            {
                return _eventDetail;
            }
            set
            {
                _eventDetail = value;
                OnPropertyChanged("EventDetail");

            }
        }
    }
}
