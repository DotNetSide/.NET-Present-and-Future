﻿using DotNetSide_EnterpriseUWP_Prism.Data;
using DotNetSide_EnterpriseUWP_Prism.Interface;
using DotNetSide_EnterpriseUWP_Prism.Service;
using DotNetSide_EnterpriseUWP_Prism.ViewModels;
using DotNetSide_EnterpriseUWP_Prism.Views;
using Microsoft.Practices.Unity;
using Prism.Events;
using Prism.Mvvm;
using Prism.Windows.Navigation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Prism.Unity.Windows;

namespace DotNetSide_EnterpriseUWP_Prism
{
    /// <summary>
    /// Fornisci un comportamento specifico dell'applicazione in supplemento alla classe Application predefinita.
    /// </summary>
    sealed partial class App : PrismUnityApplication
    {
        public App()
        {
            this.InitializeComponent();
        }

        protected override Task OnLaunchApplicationAsync(LaunchActivatedEventArgs args)
        {
            NavigationService.Navigate("Main", null);
            Window.Current.Activate();
            return Task.FromResult(true);
        }

        //protected override UIElement CreateShell(Frame rootFrame)
        //{
        //    var shell = Container.Resolve<MainPage>();

        //    return shell;
        //}

        protected override Task OnInitializeAsync(IActivatedEventArgs args)
        {
            var _eventAggregator = new EventAggregator();

            Container.RegisterInstance<INavigationService>(NavigationService);
            Container.RegisterInstance<IEventAggregator>(EventAggregator);

            Container.RegisterType<IMainPageViewModel, MainPageViewModel>();
            Container.RegisterType<IDetailPageViewModel, DetailPageViewModel>();

            Container.RegisterType<IHttpService, HttpService>(new ContainerControlledLifetimeManager());
            Container.RegisterType<IAppService, AppService>(new ContainerControlledLifetimeManager());
            Container.RegisterType<IDataService, DataService>(new ContainerControlledLifetimeManager());

            ViewModelLocationProvider.SetDefaultViewModelFactory((viewModelType) =>
            {
                return Container.Resolve(viewModelType);
            });
            return base.OnInitializeAsync(args);
        }
    }
}
