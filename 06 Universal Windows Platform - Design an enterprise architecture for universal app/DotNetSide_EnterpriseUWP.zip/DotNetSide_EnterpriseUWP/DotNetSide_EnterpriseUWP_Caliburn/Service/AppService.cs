﻿using Caliburn.Micro;
using DotNetSide_EnterpriseUWP_Caliburn.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_Caliburn.Service
{
    public class AppService : IAppService
    {
        public AppService(IHttpService httpService, IDataService dataService, INavigationService navigationService, IEventAggregator eventAggregator)
        {
            Http = httpService;
            Data = dataService;
            Navigation = navigationService;
            Event = eventAggregator;
        }

        public IHttpService Http { get; private set; }

        public IDataService Data { get; private set; }

        public INavigationService Navigation { get; private set; }

        public IEventAggregator Event { get; private set; }
    }
}
