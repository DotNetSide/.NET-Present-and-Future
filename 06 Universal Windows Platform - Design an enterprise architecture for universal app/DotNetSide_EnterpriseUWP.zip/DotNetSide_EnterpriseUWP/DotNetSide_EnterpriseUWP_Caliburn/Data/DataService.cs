﻿using DotNetSide_EnterpriseUWP_Caliburn.Data.Model;
using DotNetSide_EnterpriseUWP_Caliburn.Interface;
using SQLite.Net;
using SQLite.Net.Platform.WinRT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_Caliburn.Data
{
    public class DataService : IDataService
    {
        public string DatabasePath { get; set; }

        public DataService()
        {
            DatabasePath = System.IO.Path.Combine(Windows.Storage.ApplicationData.Current.LocalFolder.Path, "dotnetside_caliburn.sqlite"); 
        }

        public void CreateDatabase()
        {
            if (!ExistTable<DotnetSideEvent>())
            {
                using (SQLite.Net.SQLiteConnection conn = new SQLite.Net.SQLiteConnection(new SQLite.Net.Platform.WinRT.SQLitePlatformWinRT(), DatabasePath))
                {
                    conn.CreateTable<DotnetSideEvent>();
                }
            }
        }

        public bool ExistTable<T>() where T : class
        {
            bool exist = true;

            try
            {
                using (SQLiteConnection conn = new SQLiteConnection(new SQLitePlatformWinRT(), DatabasePath))
                {
                    var res = conn.Table<T>().FirstOrDefault();
                }
            }
            catch
            {
                exist = false;
            }

            return exist;
        }

        public List<DotnetSideEvent> GetEvents()
        {
            List<DotnetSideEvent> res = new List<DotnetSideEvent>();

            using (SQLiteConnection conn = new SQLiteConnection(new SQLitePlatformWinRT(), DatabasePath))
            {
                res = conn.Table<DotnetSideEvent>().OrderByDescending(x => x.Id).ToList();
            }

            return res;
        }

        public void AddEvents(List<DotnetSideEvent> events )
        {
            if (events != null && events.Count > 0)
            {
                using (SQLiteConnection conn = new SQLiteConnection(new SQLitePlatformWinRT(), DatabasePath))
                {
                    conn.InsertOrIgnoreAll(events);
                }
            }
        }

        public void SetIsFavorite(string id, bool isFavorite)
        {
            if (!String.IsNullOrEmpty(id))
            {
                using (SQLiteConnection conn = new SQLiteConnection(new SQLitePlatformWinRT(), DatabasePath))
                {
                    var obj = conn.Table<DotnetSideEvent>().Where(x => x.Id == id).FirstOrDefault();

                    if(obj != null)
                    {
                        obj.IsFavorite = isFavorite;
                        conn.Update(obj);
                    }
                }
            }
        }
    }


}
