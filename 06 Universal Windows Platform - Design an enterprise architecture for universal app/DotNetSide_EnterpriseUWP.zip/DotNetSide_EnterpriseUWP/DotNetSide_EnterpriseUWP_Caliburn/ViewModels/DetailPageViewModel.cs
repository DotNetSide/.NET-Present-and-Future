﻿using Caliburn.Micro;
using DotNetSide_EnterpriseUWP_Caliburn.Data.Model;
using DotNetSide_EnterpriseUWP_Caliburn.Infrastructure.Event;
using DotNetSide_EnterpriseUWP_Caliburn.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSide_EnterpriseUWP_Caliburn.ViewModels
{
    public class DetailPageViewModel : Screen
    {

        public DetailPageViewModel(IAppService appService)
        {
            AppService = appService;
        }

        public IAppService AppService { get; set; }

        public DotnetSideEvent Parameter { get; set; }


        public async Task LoadedCommand()
        {
            try
            {
                SubTitle = "Caliburn edition";

                if (Parameter != null)
                {
                    Title = Parameter.Title;
                    EventDetail = await AppService.Http.GetEventDetail(Parameter.Id, Parameter.LinkDetail);
                }
            }
            catch (Exception ex)
            {
                new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
            }
        }

        public void GoBack()
        {
            AppService.Navigation.GoBack();
        }

        public void ManageFavorite(string e)
        {
            try
            {
                if (EventDetail != null)
                {
                    AppService.Event.PublishOnUIThread(new SetFavoriteEventArgs() { Id = EventDetail.Id, IsFavorite = Convert.ToBoolean(e) });
                }
            }
            catch (Exception ex)
            {
                new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
            }
        }

        public void OpenAgenda()
        {
            if (EventDetail != null && !String.IsNullOrEmpty(EventDetail.LinkAgenda))
            {
                Windows.System.Launcher.LaunchUriAsync(new Uri(EventDetail.LinkAgenda));
            }
        }

        private string _title;
        public string Title
        {

            get
            {
                return _title;
            }
            set
            {
                if (value != _title)
                {
                    _title = value;
                    NotifyOfPropertyChange(() => Title);
                }
            }
        }

        private string _subtitle;
        public string SubTitle
        {

            get
            {
                return _subtitle;
            }
            set
            {
                if (value != _subtitle)
                {
                    _subtitle = value;
                    NotifyOfPropertyChange(() => SubTitle);
                }
            }
        }

        private DotnetSideEventDetail _eventDetail;
        public DotnetSideEventDetail EventDetail
        {
            get
            {
                return _eventDetail;
            }
            set
            {
                _eventDetail = value;
                NotifyOfPropertyChange(() => EventDetail);
            }
        }
    }
}
