﻿using Caliburn.Micro;
using DotNetSide_EnterpriseUWP_Caliburn.Data.Model;
using DotNetSide_EnterpriseUWP_Caliburn.Infrastructure.Event;
using DotNetSide_EnterpriseUWP_Caliburn.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace DotNetSide_EnterpriseUWP_Caliburn.ViewModels
{
    public class MainPageViewModel : Screen, IHandle<SetFavoriteEventArgs>
    {

        public MainPageViewModel(IAppService appService)
        {
            AppService = appService;
            AppService.Event.Subscribe(this);
        }

        public IAppService AppService { get; set; }


        public async Task LoadedCommand()
        {
            try
            {
                Title = "DotNetSide Journal";

                SubTitle = "Caliburn edition";

                AppService.Data.CreateDatabase();

                await LoadEvents();
            }
            catch (Exception ex)
            {
                new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
            }

        }


        public void SelectItem(ItemClickEventArgs e)
        {
            try
            {
                AppService.Navigation.NavigateToViewModel<DetailPageViewModel>(e.ClickedItem);
            }
            catch (Exception ex)
            {
                new Windows.UI.Popups.MessageDialog("Ops !! come sempre in una demo ci deve essere sempre un eccezione non gestita");
            }
        }

        private List<DotnetSideEvent> _events;
        public List<DotnetSideEvent> Events
        {
            get
            {
                return _events;
            }
            set
            {
                _events = value;
                NotifyOfPropertyChange(() => Events);

            }
        }

        private string _title;
        public string Title
        {

            get
            {
                return _title;
            }
            set
            {
                if (value != _title)
                {
                    _title = value;
                    NotifyOfPropertyChange(() => Title);
                }
            }
        }

        private string _subtitle;
        public string SubTitle
        {

            get
            {
                return _subtitle;
            }
            set
            {
                if (value != _subtitle)
                {
                    _subtitle = value;
                    NotifyOfPropertyChange(() => SubTitle);
                }
            }
        }

        private async Task LoadEvents()
        {
            var evs = AppService.Data.GetEvents();

            if (evs == null || evs.Count == 0)
            {
                evs = await AppService.Http.GetEvents();
                AppService.Data.AddEvents(evs);
            }

            Events = evs;
        }

        public void Handle(SetFavoriteEventArgs message)
        {
            if (message != null)
            {
                AppService.Data.SetIsFavorite(message.Id, message.IsFavorite);

                var el = Events.FirstOrDefault(x => x.Id == message.Id);

                if (el != null)
                {
                    el.IsFavorite = message.IsFavorite;
                }
            }
        }
    }
}
